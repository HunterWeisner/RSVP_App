﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using SQLite;
using System.Web.Http.Controllers;
using System.Text;

namespace RSVP_WS.Models
{
    public class BasicAuthenticationAttribute : System.Web.Http.Filters.ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (actionContext.Request.Headers.Authorization == null)
            {
                //nothing incldued in the authorization header, no credientials
                actionContext.Response = new System.Net.Http.HttpResponseMessage(
                    System.Net.HttpStatusCode.Unauthorized);
            }
            else
            {
                string authToken =
                    actionContext.Request.Headers.Authorization.Parameter;
                string decodedToken =
                    Encoding.UTF8.GetString(Convert.FromBase64String(authToken));
                string userId = decodedToken.Substring(0, decodedToken.IndexOf(':'));
                string pw = decodedToken.Substring(decodedToken.IndexOf(':') + 1);
                if (userId.ToUpper() == "WEISNER01" && pw == "Password01")
                {
                    //found matching credentials, user is authorized
                    actionContext.Response = new System.Net.Http.HttpResponseMessage(
                        System.Net.HttpStatusCode.OK);
                }
                else
                {
                    //unmatched credientials, unauthorized user
                    actionContext.Response = new System.Net.Http.HttpResponseMessage(
                        System.Net.HttpStatusCode.Unauthorized);
                }
            }
        }
    }
    public class DAL
    {
        private string _dbPath = Path.Combine(
        System.Environment.GetFolderPath(
            System.Environment.SpecialFolder.Personal), "RSVPDb.db");

        public DAL()
        {
            //check to see if DB exists - if not, create it
            if (!File.Exists(_dbPath))
            {
                SQLiteDB db = new SQLiteDB(_dbPath);
                db.Create();
            }
        }
        //User CRUD
        public bool AddUser(User user)
        {
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                bool exists = false;

                //error checking to prevent adding the same user twice
                foreach (User u in db.Table<User>())
                {
                    if (u.Email == user.Email)
                    {
                        exists = true;
                        break;
                    }
                }

                if (!exists)
                {
                    db.Insert(user);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Method for retreiving a user with login credentials
        /// if the login is successful return true and a user
        /// if login is unsuccessful return false and a blank user.
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool getUserByLogin(string email, string password, out User user)
        {
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                bool found = false;
                user = new User();
                foreach (User u in db.Table<User>())
                {
                    if (u.Email == email && u.Password == password)
                    {
                        user = u;
                        found = true;
                        break;
                    }
                }
                return found;
            }
        }

        /// <summary>
        /// gets a user by userId
        /// Should only be used with the id revtreived from a successful user login
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public User getUserByUserId(Int64 userId)
        {
            User user = new User();
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                foreach (User u in db.Table<User>())
                {
                    if (u.id == userId)
                    {
                        user = u;
                        break;
                    }
                }
            }

            return user;
        }

        //RSVP CRUD
        //returns a list of RSVPs for a specific userId
        public List<RSVP> getRSVPbyUserId(Int64 userId)
        {
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                List<RSVP> RSVPs = new List<RSVP>();
                foreach (RSVP r in db.Table<RSVP>())
                {
                    if (r.userId == userId)
                    {
                        RSVPs.Add(r);
                    }
                }

                return RSVPs;
            }
        }
        /// <summary>
        /// adds a row to the RSVP table
        /// Returns true on success and false on failure
        /// </summary>
        /// <param name="RSVP"></param>
        /// <returns></returns>
        public bool AddRSVP(RSVP RSVP)
        {
            bool exists = false;
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                List<RSVP> rsvps = new List<RSVP>();
                Event evnt = getEventById(RSVP.eventId)[0];
                rsvps = getRSVPbyEventId(RSVP.eventId);

                
                foreach (RSVP r in db.Table<RSVP>())
                {
                    if (r.userId == RSVP.userId && r.eventId == RSVP.eventId)
                    {
                        exists = true;
                        break;
                    }
                }
                if (!exists)
                {
                    if (evnt.MaxAtendees > rsvps.Count)//logic to prevent too many rvps to one event.
                    {
                        db.Insert(RSVP);
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
                else
                {
                    return false;
                }
                

                
            }
        }
        /// <summary>
        /// Gets a list of RSVPs for a specific eventId
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public List<RSVP> getRSVPbyEventId(Int64 eventId)
        {
            List<RSVP> RSVPs = new List<RSVP>();
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                foreach (RSVP r in db.Table<RSVP>())
                {
                    if (r.eventId == eventId)
                    {
                        RSVPs.Add(r);
                    }
                }
            }
            return RSVPs;
        }
        //Event CRUD
        /// <summary>
        /// Returns a list of events RSVP to
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Event> getEventsByUserId(Int64 userId)
        { 
            List<RSVP> RSVPs = getRSVPbyUserId(userId);
            List<Event> events = new List<Event>();
            foreach (RSVP r in RSVPs)
            {
                events.Add(getEventById(r.eventId)[0]);
            }

            return events;
        }
        /// <summary>
        /// returns a list of all events
        /// </summary>
        /// <returns></returns>
        public List<Event> getAllEvents()
        {
            List<Event> events = new List<Event>();
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                foreach (Event e in db.Table<Event>())
                {
                    events.Add(e);
                }
            }

            return events;
        }
        /// <summary>
        /// gets event by eventId
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public List<Event> getEventById(Int64 eventId)
        {
            List<Event> thisEvent = new List<Event>();
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {

                foreach (Event e in db.Table<Event>())
                {
                    if (e.id == eventId)
                    {
                        thisEvent.Add(e);
                    }
                }
            }

            return thisEvent;
        }
        /// <summary>
        /// Returns a list of events hosted by the userId
        /// </summary>
        /// <param name="HostId"></param>
        /// <returns></returns>
        public List<Event> getEventsByHostId(Int64 HostId)
        {
            List<Event> events = new List<Event>();
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                foreach (Event e in db.Table<Event>())
                {
                    if (e.Host == HostId)
                    {
                        events.Add(e);
                    }
                }
            }
            return events;
        }
        public bool addEvent(Event e)
        {
            using (SQLiteConnection db = new SQLiteConnection(_dbPath))
            {
                bool exists = false;

                //error checking to prevent adding the same event twice
                foreach (Event even in db.Table<Event>())
                {
                    if (even.Host == e.Host && even.EventDate == e.EventDate
                        && even.Address == e.Address)
                    {
                        exists = true;
                        break;
                    }
                }

                if (!exists)
                {
                    db.Insert(e);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}