﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SQLite;

namespace RSVP_WS.Models
{
    class SQLiteDB
    {
        string _path;

        public SQLiteDB(string path)
        {
            _path = path;
        }

        public void Create()
        {
            using (SQLiteConnection db = new SQLiteConnection(_path))
            {
                db.CreateTable<Event>();
                db.CreateTable<User>();
                db.CreateTable<RSVP>();
            }
        }
    }
    public partial class Event
    {
        //Holds information of an event
        [PrimaryKey, AutoIncrement]
        public Int64 id { get; set; }

        [NotNull]
        public string Name { get; set; }

        [NotNull]
        public string Address { get; set; }

        [NotNull]
        public Int64 MaxAtendees { get; set; }

        [NotNull]
        public DateTime EventDate { get; set; }

        [NotNull]
        public DateTime CutoffDate { get; set; }

        [NotNull]
        public Int64 Host { get; set; }

    }
    //class to represetn a user from the database
    public partial class User
    {
        [PrimaryKey, AutoIncrement]
        public Int64 id { get; set; }

        [NotNull]
        public string First { get; set; }

        [NotNull]
        public string Last { get; set; }

        [NotNull]
        public string Email { get; set; }

        [NotNull]
        public string Password { get; set; }

        [NotNull]
        public string Phone { get; set; }

        public User()
        {
            Email = "-1";
            Password = "-1";
        }

    }
    public partial class RSVP
    {
        [PrimaryKey, AutoIncrement]
        public Int64 id { get; set; }

        [NotNull]
        public Int64 userId { get; set; }

        [NotNull]
        public Int64 eventId { get; set; }

    }
}