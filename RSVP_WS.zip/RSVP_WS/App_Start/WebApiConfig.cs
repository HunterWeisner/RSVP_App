﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace RSVP_WS
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                name: "RSVP_API",
                routeTemplate: "api/RSVP/{id}/{value}",
                defaults: new { controller = "RSVP", id = RouteParameter.Optional, value = RouteParameter.Optional}
                );
            config.Routes.MapHttpRoute(name: "UserApi",
                routeTemplate: "api/User/{id}/{value1}/{value2}",
                defaults: new { controller = "User", id = RouteParameter.Optional, value1 = RouteParameter.Optional, value2 = RouteParameter.Optional}
                );
            config.Routes.MapHttpRoute(
                name: "EventApi",
                routeTemplate: "api/Event/{id}/{value}",
                defaults: new {controller = "Event", id = RouteParameter.Optional, value = RouteParameter.Optional }
                );
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
