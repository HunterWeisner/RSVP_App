﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RSVP_WS.Models;

namespace RSVP_WS.Controllers
{
    public class UserController : ApiController
    {

        // GET: api/User/5
        public User Get(int id, string value1, string value2)
        {
            DAL dal = new DAL();
            switch (id) 
            {
                case 0:
                    return dal.getUserByUserId(int.Parse(value1));
                case 1:
                    if (dal.getUserByLogin(value1, value2, out User user))
                    {
                        return user;
                    }
                    else
                    {
                        return new User();
                    }
                    
                default:
                    return new User();
            }
        }

        // POST: api/User
        public void Post([FromBody]User value)
        {
            DAL dal = new DAL();
            dal.AddUser(value);
        }

        // PUT: api/User/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/User/5
        public void Delete(int id)
        {
        }
    }
}
