﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace RSVP_WS.Controllers
{
    public class ValuesController : ApiController
    {

        // POST api/values
        [Models.BasicAuthentication]
        public void Post([FromBody] string value)
        {
        }

    }
}
