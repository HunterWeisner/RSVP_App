﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RSVP_WS.Models;

namespace RSVP_WS.Controllers
{
    public class EventController : ApiController
    {
        // GET: api/Event
        public IEnumerable<Event> Get()
        {
            DAL dal = new DAL();
            
            return dal.getAllEvents();
        }

        // GET: api/Event/5
        public IEnumerable<Event> Get(int id, string value)
        {
            DAL dal = new DAL();
            switch (id)
            {
                case 0:
                    return dal.getEventById(int.Parse(value));
                case 1:
                    return dal.getEventsByUserId(int.Parse(value));
                case 2:
                    return dal.getEventsByHostId(int.Parse(value));
                default:
                    return new List<Event>();
            }
        }

        // POST: api/Event
        public void Post([FromBody]Event value)
        {
            DAL dal = new DAL();

            dal.addEvent(value);
        }

    }
}
