﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RSVP_WS.Models;

namespace RSVP_WS.Controllers
{
    public class RSVPController : ApiController
    {

        // GET: api/RSVP/5
        public IEnumerable<RSVP> Get(int id, int value)
        {
            DAL dal = new DAL();
            switch (id) 
            {
                case 0:
                    return dal.getRSVPbyEventId(value);
                case 1:
                    return dal.getRSVPbyUserId(value);
                default:
                    return new List<RSVP>();
            }
        }

        // POST: api/RSVP
        public void Post([FromBody]RSVP value)
        {
            DAL dal = new DAL();
            dal.AddRSVP(value);
        }

        // PUT: api/RSVP/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/RSVP/5
        public void Delete(int id)
        {
        }
    }
}
