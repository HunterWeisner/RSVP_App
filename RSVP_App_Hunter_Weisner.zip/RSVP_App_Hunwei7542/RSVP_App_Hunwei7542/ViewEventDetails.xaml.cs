﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

namespace RSVP_App_Hunwei7542
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ViewEventDetails : ContentPage
    {
        DAL dal = new DAL();
        DAL.Event ListItem { get; set; }
        public ViewEventDetails(DAL.Event listItem)
        {
            DAL.User host = dal.getUserByUserId(listItem.Host);
            InitializeComponent();
            hostNameLabel1.Text = host.ToString();
            nameLabel1.Text = listItem.Name;
            eventDateLabel1.Text = listItem.EventDate.ToString();
            maximumLabel1.Text = listItem.MaxAtendees.ToString();
            cutOffLabel1.Text = listItem.CutoffDate.ToString();
            addressLabel1.Text = listItem.Address;

            ListItem = listItem;
        }

        private async void ButtonRSVPClicked(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            if (int.Parse(Preferences.Get("UserId", "-1")) == -1)
            {
                await Navigation.PushAsync(new RsvpPage(ListItem.id));
            }
            else
            {
                DAL.RSVP rsvp = new DAL.RSVP();
                rsvp.eventId = ListItem.id;
                rsvp.userId = int.Parse(Preferences.Get("UserId", "-1"));
                if (dal.AddRSVP(rsvp))
                {
                    rsvpStatusLabel.Text = "RSVP accepted";
                }
                else
                {
                    rsvpStatusLabel.Text = "Somthing went wrong!";
                }
            }
        }
    }
}