﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

namespace RSVP_App_Hunwei7542
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CreateUser : ContentPage
    {
        int Code { get; set; }
        public CreateUser(int code)
        {
            InitializeComponent();
            Code = code;
        }

        private async void ButtonCancelClicked(object sender, EventArgs e)
        {
            await App.Current.MainPage.Navigation.PopAsync();
        }
        private void ButtonCreateClicked(object sender, EventArgs e)
        {
            if(emailInput.Text != "" && firstInput.Text != "" && lastInput.Text != "" 
                && passwordInput.Text != "" && phoneInput.Text != "")
            {
                DAL.User user = new DAL.User();
                user.First = firstInput.Text;
                user.Last = lastInput.Text;
                user.Phone = phoneInput.Text;
                user.Email = emailInput.Text;
                user.Password = passwordInput.Text;

                DAL dal = new DAL();
                if (dal.AddUser(user))
                {
                    Preferences.Set("UserId", user.id.ToString());
                    Preferences.Set("First", user.First);
                    Preferences.Set("Last", user.Last);
                    Preferences.Set("Email", user.Email);
                    Preferences.Set("Phone", user.Phone);

                    if(Code == 1)
                    {
                        Navigation.PopAsync();
                    }
                    else
                    {
                        Navigation.PushAsync(new ViewEvents());
                    }
                }
                else
                {
                    labelCreateUserStatus.Text = "Email already in use";
                    labelCreateUserStatus.TextColor = Color.Red;
                }
                
            }
            else
            {
                labelCreateUserStatus.Text = "Please fillout all fields";
                labelCreateUserStatus.TextColor = Color.Red;
            }
        }
    }
}