﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RSVP_App_Hunwei7542
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ViewEvents : ContentPage
    {
        List<DAL.Event> Events { get; set; }
        
        public ViewEvents()
        {
            InitializeComponent();
            DAL dal = new DAL();
            Events = dal.getAllEvents();
            listViewEventsList.ItemsSource = Events;
            List<string> filters = new List<string>();
            filters.Add("All");
            filters.Add("Attending");
            filters.Add("Hosting");
            foreach (string selection in filters)
            {
                pickerFilters.Items.Add(selection);
            }
            if (Preferences.ContainsKey("UserId"))
            {
                pickerFilters.IsEnabled = true;
                pickerFilters.IsVisible = true;
                btnAddEvent.IsEnabled = true;
                btnAddEvent.IsVisible = true;
            }
            else
            {
                pickerFilters.IsEnabled = false;
                pickerFilters.IsVisible = false;
                btnAddEvent.IsEnabled = false;
                btnAddEvent.IsVisible = false;
            }
        }

        async void Handle_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            if (e.Item == null)
                return;

            await Navigation.PushAsync(new ViewEventDetails(Events[e.ItemIndex]));

            //Deselect Item
            ((ListView)sender).SelectedItem = null;
        }

        private async void btnAddEvent_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AddEvent());
        }

        private void btnLogout_Clicked(object sender, EventArgs e)
        {
            Preferences.Clear();
            App.Current.MainPage.Navigation.PopAsync();
        }

        private void pickerFilters_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            int currentUserId = int.Parse(Preferences.Get("UserId", "-1"));
            switch (pickerFilters.SelectedIndex)//events needs to be repopulated
                                                //when the itemsource is updated
                                                //to keep the indexs parallel
            {
                
                case 0:
                    Events = dal.getAllEvents();
                    listViewEventsList.ItemsSource = dal.getAllEvents();
                    break;
                case 1:
                    Events = dal.getEventsAttendedByUserId(currentUserId);
                    listViewEventsList.ItemsSource = dal.getEventsAttendedByUserId(currentUserId);
                    break;
                case 2:
                    Events = dal.getEventsByHostId(currentUserId);
                    listViewEventsList.ItemsSource = dal.getEventsByHostId(currentUserId);
                    break;
                default:
                    Events = dal.getAllEvents();
                    listViewEventsList.ItemsSource = dal.getAllEvents();
                    break;
            }
        }
    }
}
