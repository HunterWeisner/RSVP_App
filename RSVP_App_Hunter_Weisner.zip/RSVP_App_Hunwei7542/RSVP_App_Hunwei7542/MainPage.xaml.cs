﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Essentials;

namespace RSVP_App_Hunwei7542
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void ButtonLoginClicked(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            if (usernameInput.Text != "" && passwordInput.Text != "")
            {
                loginStatus.Text = "";
                if (dal.getUserByLogin(usernameInput.Text, passwordInput.Text, out DAL.User user))
                {
                    Preferences.Set("UserId", user.id.ToString());
                    Preferences.Set("First", user.First);
                    Preferences.Set("Last", user.Last);
                    Preferences.Set("Email", user.Email);
                    Preferences.Set("Phone", user.Phone);
                    loginStatus.Text = "";
                    await Navigation.PushAsync(new ViewEvents());        
                }
                else
                {
                    loginStatus.Text = "Incorrect email or password";
                }
            }
            else {
                loginStatus.Text = "Please enter a username and a password";
            }
        }
        private async void ButtonGuestClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ViewEvents());
        }
        private async void ButtonCreateClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CreateUser(0));
        }

    }
}
