﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

namespace RSVP_App_Hunwei7542
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddEvent : ContentPage
    {
        public AddEvent()
        {
            InitializeComponent();
        }

        private void ButtonSaveClicked(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            DAL.Event evnt = new DAL.Event();
            if (!String.IsNullOrEmpty(addressInput.Text) && !String.IsNullOrEmpty(maximumInput.Text)
                && !String.IsNullOrEmpty(nameInput.Text))
            {
                evnt.Host = int.Parse(Preferences.Get("UserId", "-1"));
                evnt.Address = addressInput.Text;
                evnt.CutoffDate = cutOffPicker.Date;
                evnt.MaxAtendees = int.Parse(maximumInput.Text);
                evnt.EventDate = eventDatePicker.Date;
                evnt.Name = nameInput.Text;
            }


            if (dal.AddEvent(evnt))
            {
                addEventStatusLabel.Text = "Event Added Successfully!";
            }
            else
            {
                addEventStatusLabel.Text = "There was an error adding the event";
            }
        }

        private async void ButtonCancelClicked(object sender, EventArgs e)
        {
           await Navigation.PopAsync();
        }
    }
}