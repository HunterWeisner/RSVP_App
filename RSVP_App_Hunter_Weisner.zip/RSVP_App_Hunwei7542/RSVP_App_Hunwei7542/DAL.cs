﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using SQLite;
using System.Net.Http;
using Newtonsoft.Json;

namespace RSVP_App_Hunwei7542
{
    public class DAL
    {
        //models for objects
        public partial class Event
        {
            //Holds information of an event

            public Int64 id { get; set; }

            public string Name { get; set; }

            public string Address { get; set; }

            public Int64 MaxAtendees { get; set; }
       
            public DateTime EventDate { get; set; }
    
            public DateTime CutoffDate { get; set; }

            public Int64 Host { get; set; }

        }
        //class to represetn a user from the database
        public partial class User
        {
            public Int64 id { get; set; }

            public string First { get; set; }

            public string Last { get; set; }

            public string Email { get; set; }

            public string Password { get; set; }

            public string Phone { get; set; }

            public override string ToString()
            {
                return First + " " + Last;
            }
        }
        public partial class RSVP
        {
            public Int64 id { get; set; }

            public Int64 userId { get; set; }

            public Int64 eventId { get; set; }

        }
        //Authentication
        public bool AuthenticateUser(string uid, string pw)
        {
            HttpClient client;
            const string apiURL = "api/values";

            //format for user id & password is uid:pw for basic auth
            string user = uid + ":" + pw;

            //convert string to StringContent in UTF8 format
            StringContent queryString =
                new StringContent(user, Encoding.UTF8, "application/json");
            //convert the user string to Base64 encoded string
            var authHeader =
                Convert.ToBase64String(Encoding.UTF8.GetBytes(user));

            client = new HttpClient();
            //create the URI with address and port - match the value in the DAL
            client.BaseAddress = new Uri("http://10.0.2.2:51918");
            //set the header for the webservice call - indicate basic authentication
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authHeader);
            //convert to Json
            var json = JsonConvert.SerializeObject(user);
            //post content to web service api
            HttpResponseMessage response = client.PostAsync(apiURL, queryString).Result;
            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            else
            {
                return false;
            }

        }


        //User CRUD
        public bool AddUser(User user)
        {
            HttpClient client;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");
                var content = JsonConvert.SerializeObject(user);
                var buff = System.Text.Encoding.UTF8.GetBytes(content);
                var byteContent = new ByteArrayContent(buff);
                byteContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                HttpResponseMessage response =
                    client.PostAsync("http://10.0.2.2:51918/api/User", byteContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Method for retreiving a user with login credentials
        /// if the login is successful return true and a user
        /// if login is unsuccessful return false and a blank user.
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool getUserByLogin(string email, string password, out User user)
        {
               
            user = new User();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/User" + "/"+ "1" +"/" + email + "/" + password;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    user = JsonConvert.DeserializeObject<User>(content);
                    return true;
                }
                else
                {
                    return false;
                }

                    
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }

        /// <summary>
        /// gets a user by userId
        /// Should only be used with the id revtreived from a successful user login
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public User getUserByUserId(Int64 userId)
        {
            User user = new User();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/User" + "/" + "0" + "/" + userId + "/" + "0";

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    user = JsonConvert.DeserializeObject<User>(content);

                }

                return user;



            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //RSVP CRUD
        //returns a list of RSVPs for a specific userId
        public List<RSVP> getRSVPbyUserId(Int64 userId)
        {
            List<RSVP> RSVPs = new List<RSVP>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/RSVP" + "/" + "1" + "/" + userId;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    RSVPs = JsonConvert.DeserializeObject<List<RSVP>>(content);

                }

                return RSVPs;



            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// adds a row to the RSVP table
        /// Returns true on success and false on failure
        /// </summary>
        /// <param name="RSVP"></param>
        /// <returns></returns>
        public bool AddRSVP(RSVP RSVP)
        {
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/RSVP";
            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");
                var content = JsonConvert.SerializeObject(RSVP);
                var buff = System.Text.Encoding.UTF8.GetBytes(content);
                var byteContent = new ByteArrayContent(buff);
                byteContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                HttpResponseMessage response =
                    client.PostAsync(queryString, byteContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// Gets a list of RSVPs for a specific eventId
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public List<RSVP> getRSVPbyEventId(Int64 eventId)
        {
            List<RSVP> RSVPs = new List<RSVP>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/RSVP" + "/" + "0" + "/" + eventId;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    RSVPs = JsonConvert.DeserializeObject<List<RSVP>>(content);

                }

                return RSVPs;



            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //Event CRUD
        /// <summary>
        /// Sends a Post request with the Attatched Event
        /// Returns true on success
        /// </summary>
        /// <param name="evnt"></param>
        /// <returns></returns>
        public bool AddEvent(Event evnt)
        {
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/Event";
            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");
                var content = JsonConvert.SerializeObject(evnt);
                var buff = System.Text.Encoding.UTF8.GetBytes(content);
                var byteContent = new ByteArrayContent(buff);
                byteContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                HttpResponseMessage response =
                    client.PostAsync(queryString, byteContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// Returns a list of events hosted by the userId
        /// </summary>
        /// <param name="HostId"></param>
        /// <returns></returns>
        public List<Event> getEventsByHostId(Int64 hostId)
        {
            List<Event> events = new List<Event>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/Event" + "/" + "2" + "/" + hostId;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    events = JsonConvert.DeserializeObject<List<Event>>(content);

                }

                return events;



            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// Returns a list of events RSVP to
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Event> getEventsAttendedByUserId(Int64 userId)
        {
            List<Event> events = new List<Event>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/Event" + "/" + "1" + "/" + userId;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    events = JsonConvert.DeserializeObject<List<Event>>(content);

                }

                return events;



            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// returns a list of all events
        /// </summary>
        /// <returns></returns>
        public List<Event> getAllEvents()
        {
            List<Event> events = new List<Event>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/Event";

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    events = JsonConvert.DeserializeObject<List<Event>>(content);

                }

                return events;



            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// gets event by eventId
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public Event getEventById(Int64 eventId)
        {
            List<Event> events = new List<Event>();
            HttpClient client;
            string queryString = "http://10.0.2.2:51918/api/Event" + "/" + "0" + "/" + eventId;

            try
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "Text/html,application/json");

                var response = client.GetAsync(queryString).Result;
                if (response.IsSuccessStatusCode)
                {
                    var content = response.Content.ReadAsStringAsync().Result;
                    events = JsonConvert.DeserializeObject<List<Event>>(content);

                }

                return events[0];



            }
            catch (Exception e)
            {
                throw e;
            }
        }

        
    }
}
