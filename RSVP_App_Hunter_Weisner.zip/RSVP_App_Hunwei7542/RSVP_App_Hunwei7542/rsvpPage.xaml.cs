﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

namespace RSVP_App_Hunwei7542
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RsvpPage : ContentPage
    {
        DAL.Event evnt;
        public RsvpPage(Int64 evntId)
        {
            DAL dal = new DAL();
            evnt = dal.getEventById(evntId);
            InitializeComponent();
            labelEventName.Text = evnt.Name;
        }


        private async void btnCancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ViewEvents());
        }

        private async void btnRSVP_Clicked(object sender, EventArgs e)
        {
            if (int.Parse(Preferences.Get("UserId", "-1")) == -1)
            {
                statusLabel.Text = "Please Login to submit an RSVP for this Event";
            }
            else
            {
                DAL dal = new DAL();
                DAL.RSVP rsvp = new DAL.RSVP();
                rsvp.eventId = evnt.id;
                rsvp.userId = int.Parse(Preferences.Get("UserId", "-1"));
                if (dal.AddRSVP(rsvp))
                {
                    statusLabel.Text = "RSVP Created";
                    await Navigation.PushAsync(new ViewEvents());
                }
                else
                {
                    statusLabel.Text = "There was an Error Adding your RSVP";
                }
            }
        }
        private void btnCreateUser_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new CreateUser(1));
        }
    }
}